#ifndef __LO_ROUTEX_H
#define __LO_ROUTEX_H

#include "Arduino.h"
#include <RHReliableDatagram.h>
#include <RH_RF95.h>
#include <SPI.h>

class Routex {
	public:
		/* Constants */
    		static const int LORA_ADDRESS = 100;
    
    		static const char NO_PARAM = 'B';
    		static const char PARAM = 'I';

    		static const char STATUS = 'S';
    		static const char NUMBER = 'N';
    		static const char TEXT = 'T';
	
		/* Variables */
    		RH_RF95 driver;
    		RHReliableDatagram manager;

		/* Constructor */
		Routex(int addr, bool alwaysOn);

		/* Functions */
		int init(float freq, long bw, int sf);
		int registerDevice(String devName);
		int registerService(String servName, char type);
		int addCommandToService(String commandName, char type);
		int doneService();	
		int serviceResponse(String res);		
		int checkServiceRequest();
		int askForCommands();
		int sendServiceValue(String servName, String value);
		int goToSleep();
		int wakeUp();
		String getRequestedServiceName();
		String getRequestedServiceCommand();
    		String getRequestedServiceArgument();
	
	protected:
		String name;
		bool alwaysOn;
		unsigned long alwaysOnTimeout;
		int addr;
		String lastService;
		String lastCommand;
    		String lastArgument;
    		uint8_t buf[RH_RF95_MAX_MESSAGE_LEN];
    		uint8_t len = sizeof(buf);
    		bool registered = false;
		int send(uint8_t data[], int datalen, int addr);
		int receive(uint8_t buf[], uint8_t* len, uint8_t* from);
    		String getServiceName(String s); 
    		String getCommand(String s); 
};

#endif
