#ifndef __ROUTEX_H
#define __ROUTEX_H

#include "Arduino.h"
#include <ESP8266WiFi.h>

class Routex {
	public:
		/* Constants */
    		static const int NRF24_ADDRESS = 100;
    
   		static const int NRF24 = 0;
    		static const int ZIGBEE = 1;
		static const int WIFI = 2;
    		static const int RFLINK = 3;

    		static const char NO_PARAM = 'B';
    		static const char PARAM = 'I';

    		static const char STATUS = 'S';
    		static const char NUMBER = 'N';
    		static const char TEXT = 'T';
	
		/* Variables */
		WiFiClient client;
		WiFiServer server;

		/* Constructor */
		Routex(int technology, char* ssid, char* password, bool alwaysOn);

		/* Functions */
		int init(uint16_t port);
		int registerDevice(String devName);
		int registerService(String servName, char type);
		int addCommandToService(String commandName, char type);
		int doneService();	
		int serviceResponse(String res);
		int sendServiceValue(String servName, String value);	
		int checkServiceRequest();
		int askForCommands();
		int goToSleep();
		int wakeUp();
		String getRequestedServiceName();
		String getRequestedServiceCommand();
    		String getRequestedServiceArgument();
	
	protected:
		static const int MAX_MESSAGE_LEN = 27;
		
		String name;
		int technology;
		int alwaysOn;
		unsigned long alwaysOnTimeout;
		int nrf_addr;
		String lastService;
		String lastCommand;
    		String lastArgument;
		bool setupdone = false;
		char* ssid;
		char* password;
		//char* ipAddress;
		IPAddress ipAddress;
		uint16_t port;
    		uint8_t buf[MAX_MESSAGE_LEN];
    		uint8_t len = sizeof(buf);
    		bool registered = false;
		int send(uint8_t data[], int datalen, int addr);
		int receive(uint8_t buf[], uint8_t* len, uint8_t* from);
    		String getServiceName(String s); 
    		String getCommand(String s); 
};

#endif
