#include "Arduino.h"
#include <ESP8266WiFi.h>
#include "ESPRoutex.h"


Routex::Routex(int technology, char* ssid, char* password, bool alwaysOn): server(5000) {
	if (technology != WIFI) {
		return;
	}

	this->ssid = ssid;
	this->password = password;
	
	this->technology = technology;
	this->alwaysOn = alwaysOn;

	alwaysOnTimeout = 0;	
}      

int Routex::init(uint16_t port) {
	if (technology != WIFI) {
		return -1;
	}

	WiFi.begin(ssid, password);
	while (WiFi.status() != WL_CONNECTED) {
		delay(500);
		Serial.print(".");
  	}
  	Serial.println("");
  	Serial.println("WiFi connected");
 
  	// Print the IP address
  	Serial.print("Received IP: ");
  	Serial.println(WiFi.localIP());

	Serial.print("Router IP: ");
	Serial.print(WiFi.gatewayIP());	

	//this->ipAddress = ipAddress; 
	this->ipAddress = WiFi.gatewayIP(); 
	this->port = port;
  	
	/*if (!client.connect(ipAddress, port)) {
      		Serial.println("Connection failed");
      		return -1;
  	} */

	server.begin();

	return 1;
}

int Routex::init(uint16_t port) {
	if (technology != WIFI) {
		return -1;
	}

	WiFi.begin(ssid, password);
	while (WiFi.status() != WL_CONNECTED) {
		delay(500);
		Serial.print(".");
  	}
  	Serial.println("");
  	Serial.println("WiFi connected");
 
  	// Print the IP address
  	Serial.print("Received IP: ");
  	Serial.println(WiFi.localIP());

	Serial.print("Router IP: ");
	Serial.print(WiFi.gatewayIP());	

	//this->ipAddress = ipAddress; 
	this->ipAddress.fromString(ipString); 
	this->port = port;
  	
	server.begin();

	return 1;
}

int Routex::goToSleep() {
	WiFi.disconnect();
	WiFi.mode(WIFI_OFF);

	return 1;
}

int Routex::wakeUp() {
	WiFi.mode(WIFI_STA);
	Serial.println("Woke Up!");

	init(this->port);

	registerDevice(this->name);

	return 1;
}

int Routex::send(uint8_t data[], int datalen, int dest) {
	switch (technology) {
		case NRF24:
			break;

		case WIFI:
			if (!client.connected()) {
				Serial.println("Need new connection");
				if (!client.connect(ipAddress, port)) {
      					Serial.println("Connection failed");
      					return -1;
  				} 
			}

			client.print((char*)data);
			break;
		
		case ZIGBEE:
			break;
	}
}

int Routex::receive(uint8_t buf[], uint8_t* len, uint8_t* from) {
	switch (technology) {
		case NRF24:
			return -1;

		case ZIGBEE:
			return 0;

		case WIFI:
  			String line = String();

			if (server.hasClient()) {
				Serial.println("---Has client---");
				client = server.available();
			}
  
			//Serial.println("Client read");	
  			int timeout = millis() + 1000;
  			while (line == "" && millis() < timeout) {
    				line = client.readStringUntil('\n');
    				delay(100);
  			}


  			if (line != "") { 
				*from = 0;
				*len = line.length();
				line.toCharArray((char*)buf, MAX_MESSAGE_LEN);
				return 1;
			}
	}
}

int Routex::registerDevice(String devName) {
	uint8_t from;
	uint8_t data[27];
	char charName[20];

	this->registered = false;

	/* Settind data string */
	devName.toCharArray(charName, 20);
	strcpy((char*)data, "J!");
	strcat((char*)data, charName);
	
	if (this->alwaysOn) strcat((char*)data, "!A");
	if (!this->alwaysOn) strcat((char*)data, "!F");

	/* Set object name */
	if (devName.length() > 20) return -1; 
	this->name = devName;

	while (!registered) {
		/* Send Register Request */
		if (!registered) {
			send(data, sizeof(data), 1);
		}     

		int timeout = millis() + 5000;
		while (!registered && timeout > millis()) {
			if (receive(buf, &len, &from))
			{
				buf[len] = '\0';

				String s = String((char*)buf);

				if (s.equals(String("J!Ok"))) {
					registered = true;
					this->name = name;
					client.stop();
					return 1;
				}   
			}
			delay(160);
		}
	}
}

int Routex::registerService(String servName, char type) {
	uint8_t from;
	uint8_t data[27];
	char charName[20];
	bool done = false;
	
	setupdone = false;

	/* Settind data string */
	servName.toCharArray(charName, 20);
	strcpy((char*)data, "S!A!X!");
	data[4] = type;

	strcat((char*)data, charName);

	while (!done) {
		send(data, sizeof(data), 1);

		int timeout = millis() + 3000;
		while (!done && timeout > millis()) {
			len = MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				buf[len] = '\0';

				String s = String((char*)buf);

				if (s.equals(String("S!G!Ok"))) {
					done = true;
					this->name = name;
					//client.stop();
					return 1;
				}   
			}
			delay(160);

		}
	}
}

int Routex::addCommandToService(String commandName, char type) {
	uint8_t data[27] = "S!B!";
	bool done = false;
	uint8_t from;
	char charName[20];

	data[2] = type;

	commandName.toCharArray(charName, 20);

	strcat((char*)data, charName);

	while (!done) {
		Serial.println("Send command");
		send(data, sizeof(data), 1);
		int timeout = millis() + 4000;
		while (!done && timeout > millis()) {
			len = MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				buf[len] = '\0';

				String s = String((char*)buf);

				if (s.equals(String("C!Added"))) {
					done = true;
					this->name = name;
					return 1;
					delay(300);
				}   
			}
			delay(160);

		}
	}

}

int Routex::doneService() {
	uint8_t data[] = "S!DONE";
	bool done = false;
	uint8_t from;

	while (!done) {
		send(data, sizeof(data), 1);
		int timeout = millis() + 5000;
		while (!done && timeout > millis()) {
			len = MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				buf[len] = '\0';

				String s = String((char*)buf);

				if (s.equals(String("S!DONE!Ok"))) {
					done = true;
					this->name = name;
					client.stop();
					delay(300);
				
					/* WiFi */		
					setupdone = true;					

					return 1;
				}   
			}
			delay(160);

		}
	}
}


int Routex::serviceResponse(String res) {
	uint8_t data[27] = "R!";
	uint8_t b[25];
	uint8_t l = 27;
	res.toCharArray((char*)b, 25);

	strcat((char*)data, (char*)b);

	/* TODO Timeout */
	//int timeout = millis() + 4000;
	
	send(data, sizeof(data), 1);
}


int Routex::sendServiceValue(String servName, String value) {
        uint8_t data[27] = "S!U!";
        uint8_t serv[25];
        uint8_t l = 27; 
        uint8_t from;
        servName.toCharArray((char*)serv, 25);

        strcat((char*)data, (char*)serv);
    
        bool done = false;
        while (!done) {
                send(data, sizeof(data), 1); 
                unsigned long timeout = millis() + 5000;
                while (!done && timeout > millis()) {
                        len = MAX_MESSAGE_LEN;
                        if (receive(buf, &len, &from)) {
				buf[len] = '\0';
                                String s = String((char*)buf);

                                if (s.equals(String("S!U!Ok"))) {
                                        done = true;
                                }
                        }
                }
                if (!done && timeout < millis()) break;
        }

        if (done) serviceResponse(value);
}


int Routex::checkServiceRequest() {
	uint8_t myfrom;
	uint8_t mybuf[MAX_MESSAGE_LEN];
	uint8_t mylen;

	if (alwaysOnTimeout == 0) {
                alwaysOnTimeout = millis() + 8000;
        }
    
        if (alwaysOnTimeout < millis()) {
                alwaysOnTimeout = 0;
                return 3;  
        }

	mylen = MAX_MESSAGE_LEN;

	if (receive(mybuf, &mylen, &myfrom)) {          
		mybuf[mylen] = '\0';

		String s = String((char*)mybuf);

		if (s.equals("W!FINISHED")) {
                        alwaysOnTimeout = 0;
                        return 2;
                }

		lastService = getServiceName(s);

		lastCommand = getCommand(s);

		if (lastCommand[lastCommand.length()-1] == '*') {
			/* Remove * from command */
			lastCommand.remove(lastCommand.length()-1);

			bool done = false;
			mylen = MAX_MESSAGE_LEN;
			while (!done) {
				if (receive(mybuf, &mylen, &myfrom)) { 
					mybuf[mylen] = '\0';

					if (mybuf[0] != '*') continue;

					s = String((char*)mybuf);

					String arg = s.substring(s.indexOf('!')+1);
					lastArgument = arg;
					done = true;
				}
			}
		}
		alwaysOnTimeout = 0;
		return 1;
	}
	return -1;
}


int Routex::askForCommands() {
        uint8_t data[8] = "W!AWAKE";
        uint8_t l = 8;

        send(data, sizeof(data), 1);

	client.stop();

        return 1;
}


String Routex::getRequestedServiceName() {
	return lastService;
}

String Routex::getRequestedServiceCommand() {
	return lastCommand;
}

String Routex::getRequestedServiceArgument() {
	return lastArgument;
}

String Routex::getServiceName(String s) {
	return s.substring(0, s.indexOf('!'));
}

String Routex::getCommand(String s) {
	return s.substring(s.indexOf('!')+1);
}
