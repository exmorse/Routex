#include "Arduino.h"
#include <RHReliableDatagram.h>
#include <RH_NRF24.h>
#include <SPI.h>
#include <XBee.h>
#include <VirtualWire.h>
#include "Routex.h"

Routex::Routex(int technology, int addr, bool alwaysOn): manager(driver, addr), addr64(0x00000000, 0x00000000) {      
	switch (technology) {
		case NRF24:
			nrf_addr = addr;
			break;
		case ZIGBEE:
			break;
		case RF433:
			rf433_addr = addr;
			break;
	}

	this->technology = technology;
	this->alwaysOn = alwaysOn;
	alwaysOnTimeout = 0;
}

int Routex::init() {
	switch (technology) {
		case NRF24:
			return manager.init();
			break;

		case ZIGBEE:
			xbee.setSerial(Serial);
			return 1;

		case RF433:
			vw_set_ptt_inverted(true); 
  			vw_setup(500); 
  			vw_set_rx_pin(2);
  			vw_rx_start();  
  			vw_set_tx_pin(3);
			return 1;
	}
}

int Routex::goToSleep() {
	switch (technology) {
		case NRF24:
			return (int) driver.sleep();
		
		case RF433:
			vw_rx_stop();
			return 1;

		case ZIGBEE:
			return 1;	
	}
}

int Routex::wakeUp() {
	switch (technology) {
		case NRF24:
			return 1;

		case RF433:
			vw_rx_start();
			return 1;

		case ZIGBEE:
			return 1;
	}
}

/* TODO Timout in NRF */
int Routex::send(uint8_t data[], int datalen, int dest) {
	unsigned long timeout = millis() + 3000;
	switch (technology) {

		case NRF24:
			//Serial.println("Inside, send");
			//Serial.println((char*)data);
			//Serial.println(datalen);
			while (!manager.sendtoWait(data, datalen, 1)) {
				if (millis() > timeout) {
					//Serial.println("Send Timeout");
					break;
				}
				delay(160);
			}
			//Serial.println("Sent");
			return 1;
	
		case RF433:
                        //Serial.println((char*)data);
                        //Serial.println(datalen);

			/* Adding myaddr and R (Routex) */
			uint8_t msgAndAddr[27];
			msgAndAddr[0] = char(rf433_addr);
			msgAndAddr[1] = 'R';
			msgAndAddr[2] = '\0';
	
			strcat((char*)msgAndAddr, (char*)data);

                        vw_send((uint8_t *)msgAndAddr, strlen((char*)msgAndAddr));
    			vw_wait_tx();
			return 1;
	
		case ZIGBEE:
			ZBTxRequest msg = ZBTxRequest(addr64, data, datalen);
			xbee.send(msg);
			return 1;

	}
}

/* TODO Ciclo available in NRF */
int Routex::receive(uint8_t buf[], uint8_t* len, uint8_t* from) {
	switch (technology) {
		case NRF24:
			if (manager.available()) {
				//Serial.println("Message Available");
				return manager.recvfromAck(buf, len, from);
			}
			return 0;

		case ZIGBEE:
			xbee.readPacket();
			if (xbee.getResponse().isAvailable()) {
				if (xbee.getResponse().getApiId() == ZB_RX_RESPONSE) {
					xbee.getResponse().getZBRxResponse(rx);
					*len = rx.getDataLength();
					*from = 0;
					int i;
					for (i = 0; i < *len; i++) buf[i] = rx.getData(i);
					buf[*len] = 0;
					return 1;
				}
			}
			return 0;

		case RF433:
			if (vw_get_message(buf, len)) {
				//Serial.println("Received Something - 433");
				//Serial.print("Received : ");
				//Serial.println((char*) buf);
				//Serial.print(" -- len : ");
				//Serial.println(*len);
				if (buf[0] != 'R' || buf[1] != rf433_addr) {
					/* Not for me */
					//Serial.println("Received message not for me");
					return 0;
				}

				int i;
				for (i = 2; i <= *len; i++) buf[i-2] = buf[i];

				//Serial.print("Message content is : ");
				//Serial.println((char*)buf);

				*len = *len - 2;
				return 1;
			}
			return 0;
	}
}

int Routex::registerDevice(String devName) {
	uint8_t from;
	uint8_t data[27];
	char charName[20];

	/* Settind data string */
	devName.toCharArray(charName, 20);
	strcpy((char*)data, "J!");
	strcat((char*)data, charName);

	if (this->alwaysOn) strcat((char*)data, "!A");
	if (!this->alwaysOn) strcat((char*)data, "!F");

	/* Set object name */
	if (devName.length() > 20) return -1; 
	this->name = devName;

	while (!registered) {
		/* Send Register Request */
		if (!registered) {
			//Serial.println("Sending register request");
			send(data, sizeof(data), 1);
		}     

		unsigned long timeout = millis() + 5000;
		while (!registered && timeout > millis()) {
			//Serial.println("[RegisterDevice] Waiting for Ack");
			if (receive(buf, &len, &from))
			{
				//Serial.print("got request from : 0x");
				//Serial.print(from, HEX);
				//Serial.print(": ");
				//Serial.println((char*)buf);
				buf[len] = '\0';

				String s = String((char*)buf);
				//Serial.print("Converted to ");
				//Serial.println(s);

				if (s.equals(String("J!Ok"))) {
					//Serial.println("Registered Successfully");
					registered = true;
					this->name = name;
					return 1;
				}   
			}
			delay(160);
		}
		if (!registered); //Serial.println("TimeoutExpired");
	}
}

int Routex::registerService(String servName, char type) {
	uint8_t from;
	uint8_t data[27];
	char charName[20];
	bool done = false;

	/* Settind data string */
	servName.toCharArray(charName, 20);
	strcpy((char*)data, "S!A!X!");
	data[4] = type;

	strcat((char*)data, charName);

	while (!done) {
		send(data, sizeof(data), 1);

		unsigned long timeout = millis() + 3000;
		while (!done && timeout > millis()) {
			//Serial.println("[RegisterService] Waiting for Ack");
			len = RH_NRF24_MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				//Serial.print("got request from : 0x");
				//Serial.print(from, HEX);
				//Serial.print(": ");
				//Serial.println((char*)buf);
				buf[len] = '\0';

				String s = String((char*)buf);
				//Serial.print("Converted to ");
				//Serial.println(s);

				if (s.equals(String("S!G!Ok"))) {
					//Serial.println("Service Declared");
					done = true;
					this->name = name;
					return 1;
				}   
			}
			delay(160);

		}
		//if (done) Serial.println("TimeoutExpired, retrying");
	}
}

int Routex::addCommandToService(String commandName, char type) {
	uint8_t data[27] = "S!B!";
	bool done = false;
	uint8_t from;
	char charName[20];

	data[2] = type;

	commandName.toCharArray(charName, 20);

	strcat((char*)data, charName);

	while (!done) {
		send(data, sizeof(data), 1);
		unsigned long timeout = millis() + 4000;
		while (!done && timeout > millis()) {
			//Serial.println("[Add Com] Waiting for Ack");
			len = RH_NRF24_MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				//Serial.print("got request from : 0x");
				//Serial.print(from, HEX);
				//Serial.print(": ");
				//Serial.println((char*)buf);
				buf[len] = '\0';

				String s = String((char*)buf);
				//Serial.print("Converted to ");
				//Serial.println(s);

				if (s.equals(String("C!Added"))) {
					//Serial.println("Command Added");
					done = true;
					this->name = name;
					return 1;
					delay(300);
				}   
			}
			delay(160);

		}
		//if (!done) Serial.println("[Add Com] Timeout");
	}

}

int Routex::doneService() {
	uint8_t data[] = "S!DONE";
	bool done = false;
	uint8_t from;

	while (!done) {
		send(data, sizeof(data), 1);
		unsigned long timeout = millis() + 3500;
		while (!done && timeout > millis()) {
			//Serial.println("[DONE] Waiting for Ack");
			len = RH_NRF24_MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from))
			{
				//Serial.print("got request from : 0x");
				//Serial.print(from, HEX);
				//Serial.print(": ");
				//Serial.println((char*)buf);
				buf[len] = '\0';

				String s = String((char*)buf);
				//Serial.print("Converted to ");
				//Serial.println(s);

				if (s.equals(String("S!DONE!Ok"))) {
					//Serial.println("Service Done");
					done = true;
					this->name = name;
					delay(300);
					return 1;
				}   
			}
			delay(160);

		}
		//if (!registered) Serial.println("[DONE] Retrying");
	}
}


int Routex::serviceResponse(String res) {
	uint8_t data[27] = "R!";
	uint8_t b[25];
	uint8_t l = 27;
	res.toCharArray((char*)b, 25);

	strcat((char*)data, (char*)b);

	//Serial.print("Response: ");
	//Serial.println((char*)data);

	/* TODO Timeout */
	unsigned long timeout = millis() + 4000;

	send(data, sizeof(data), 1);
}


int Routex::sendServiceValue(String servName, String value) {
	uint8_t data[27] = "S!U!";
	uint8_t serv[25];
	uint8_t l = 27;
	uint8_t from;
	servName.toCharArray((char*)serv, 25);

	strcat((char*)data, (char*)serv);
	
	bool done = false;
	while (!done) {
		send(data, sizeof(data), 1);
		unsigned long timeout = millis() + 5000;
		while (!done && timeout > millis()) {
			len = RH_NRF24_MAX_MESSAGE_LEN;
			if (receive(buf, &len, &from)) {
				buf[len] = '\0';
				String s = String((char*)buf);
	
				if (s.equals(String("S!U!Ok"))) {
					done = true;
				}
			}
		}
		if (!done && timeout < millis()) break;
	}			
		
	if (done) serviceResponse(value);
}

int Routex::checkServiceRequest() {
	uint8_t myfrom;
	uint8_t mybuf[RH_NRF24_MAX_MESSAGE_LEN];
	uint8_t mylen;

	if (alwaysOnTimeout == 0) {
		alwaysOnTimeout = millis() + 8000;
	}
	
	if (alwaysOnTimeout < millis()) {
		alwaysOnTimeout = 0;
		return 3; 
	}

	mylen = RH_NRF24_MAX_MESSAGE_LEN;
	//if (manager.available()) {
	if (receive(mybuf, &mylen, &myfrom)) {          
		//Serial.print("got request from : 0x");
		//Serial.print(myfrom, HEX);
		//Serial.print(": ");
		//Serial.println((char*)mybuf);
		mybuf[mylen] = '\0';

		String s = String((char*)mybuf);
		//Serial.print("\nConverted to ");
		//Serial.println(s);

		if (s.equals("W!FINISHED")) {
			alwaysOnTimeout = 0;
			return 2;
		}
		
		//Serial.print("S : ");
		lastService = getServiceName(s);
		//Serial.println(lastService);

		//Serial.print("C : ");
		lastCommand = getCommand(s);
		//Serial.println(lastCommand);

		if (lastCommand[lastCommand.length()-1] == '*') {
			/* Remove * from command */
			lastCommand.remove(lastCommand.length()-1);

			if (technology == RF433) {
				uint8_t ack433 [7] = "OK!ARG";
				send(ack433, sizeof(ack433), 1);
			}

			//Serial.println("Now i'm expecting an argument");
			bool done = false;
			mylen = RH_NRF24_MAX_MESSAGE_LEN;
			while (!done) {
				//if (manager.available()) {
				if (receive(mybuf, &mylen, &myfrom)) { 
					//Serial.print("got arg from : 0x");
					//Serial.print(myfrom, HEX);
					//Serial.print(": ");
					//Serial.println((char*)mybuf);
					mybuf[mylen] = '\0';

					if (mybuf[0] != '*') continue;

					s = String((char*)mybuf);
					//Serial.print("\n Arg converte to ");
					//Serial.println(s);

					String arg = s.substring(s.indexOf('!')+1);
					//Serial.println(arg);
					lastArgument = arg;
					done = true;
				}
			}
		}
		alwaysOnTimeout = 0;
		return 1;
	}
	return -1;
}

int Routex::askForCommands() {
	uint8_t data[8] = "W!AWAKE";
	uint8_t l = 8;

	send(data, sizeof(data), 1);
	
	uint8_t myfrom;
	uint8_t mybuf[RH_NRF24_MAX_MESSAGE_LEN];
	uint8_t mylen;

	/*int timeout = millis() + 4000;

	mylen = RH_NRF24_MAX_MESSAGE_LEN;
	while (millis() < timeout) {
		if (receive(mybuf, &mylen, &myfrom)) {          
			mybuf[mylen] = '\0';

			String s = String((char*)mybuf);

			Serial.println(s);

			if (s.equals("W!OK")) {
				return 1;
			}
		}
	}
	return 0;*/
	return 1;
}

String Routex::getRequestedServiceName() {
	return lastService;
}

String Routex::getRequestedServiceCommand() {
	return lastCommand;
}

String Routex::getRequestedServiceArgument() {
	return lastArgument;
}

String Routex::getServiceName(String s) {
	return s.substring(0, s.indexOf('!'));
}

String Routex::getCommand(String s) {
	return s.substring(s.indexOf('!')+1);
}
