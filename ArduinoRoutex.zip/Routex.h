#ifndef __ROUTEX_H
#define __ROUTEX_H

#include "Arduino.h"
#include <RHReliableDatagram.h>
#include <RH_NRF24.h>
#include <SPI.h>
#include <XBee.h>
#include <VirtualWire.h>

class Routex {
	public:
		/* Constants */
    		static const int NRF24_ADDRESS = 100;
    
   		static const int NRF24 = 0;
    		static const int ZIGBEE = 1;
    		static const int RF433 = 2;

    		static const char NO_PARAM = 'B';
    		static const char PARAM = 'I';

    		static const char STATUS = 'S';
    		static const char NUMBER = 'N';
    		static const char TEXT = 'T';
	
		/* Variables */
    		RH_NRF24 driver;
    		RHReliableDatagram manager;
		XBee xbee;
    		XBeeAddress64 addr64;
    		ZBTxStatusResponse tx_res;
    		ZBRxResponse rx;

		/* Constructor */
		Routex(int technology, int addr, bool alwaysOn);

		/* Functions */
		int init();
		int registerDevice(String devName);
		int registerService(String servName, char type);
		int addCommandToService(String commandName, char type);
		int doneService();	
		int serviceResponse(String res);		
		int checkServiceRequest();
		int askForCommands();
		int sendServiceValue(String servName, String value);
		int goToSleep();
		int wakeUp();
		String getRequestedServiceName();
		String getRequestedServiceCommand();
    		String getRequestedServiceArgument();
	
	protected:
		String name;
		int technology;
		bool alwaysOn;
		unsigned long alwaysOnTimeout;
		int nrf_addr;
		int rf433_addr;
		String lastService;
		String lastCommand;
    		String lastArgument;
    		uint8_t buf[RH_NRF24_MAX_MESSAGE_LEN];
    		uint8_t len = sizeof(buf);
    		bool registered = false;
		int send(uint8_t data[], int datalen, int addr);
		int receive(uint8_t buf[], uint8_t* len, uint8_t* from);
    		String getServiceName(String s); 
    		String getCommand(String s); 
};

#endif
