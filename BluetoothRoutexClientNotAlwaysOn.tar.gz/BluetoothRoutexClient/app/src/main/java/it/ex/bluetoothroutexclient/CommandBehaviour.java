package it.ex.bluetoothroutexclient;

import android.content.Context;

/**
 * Created by ex on 09/08/16.
 */
public interface CommandBehaviour {
    String execute(Context c, String argument);
}
