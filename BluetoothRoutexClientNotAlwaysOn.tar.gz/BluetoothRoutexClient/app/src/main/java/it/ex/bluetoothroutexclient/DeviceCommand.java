package it.ex.bluetoothroutexclient;

import android.content.Context;

/**
 * Created by ex on 09/08/16.
 */
public class DeviceCommand {

    protected String name;
    protected CommandBehaviour cb;
    protected char type;

    public DeviceCommand(String name, char type, CommandBehaviour cb) {
        this.name = name;
        this.cb = cb;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public char getType() {
        return type;
    }

    public String run (Context c, String arg) {
        return cb.execute(c, arg);
    }
}
