package it.ex.bluetoothroutexclient;

import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class BluetoothRoutexService extends Service {

    Context context;
    static  boolean isActive;

    static ArrayList<DeviceService> services;
    static boolean alwaysOn;

    static BluetoothAdapter mba;

    static BluetoothRoutexManager routexManager;


    public BluetoothRoutexService() {
    }

    public static void setServices(ArrayList<DeviceService> serviceArrayList) {
        services = (ArrayList<DeviceService>) serviceArrayList.clone();
    }

    public static String execute(Context context, String serviceName, String commandName, String argument) {

        int i;
        for (i = 0; i < services.size(); i++) {
            DeviceService serv = services.get(i);
            if (serv.getName().matches(serviceName)) {
                int j;
                for (j = 0; j < serv.getCommands().size(); j++) {
                    DeviceCommand com = serv.getCommands().get(j);
                    if (com.getName().matches(commandName)) {
                        return com.run(context, argument);
                    }
                }
            }
        }

        return "Not Found";
    }


    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }


    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onCreate();
        context = getApplicationContext();
        isActive = true;
        Log.w("Service", "Started");

        //Log.w("Static Services", RoutexCommandsHandler.services.toString());

        mba = BluetoothAdapter.getDefaultAdapter();
        routexManager = new BluetoothRoutexManager(context, this, mba, alwaysOn);

        if (intent == null) return 0;

        //services = (ArrayList<DeviceService>) intent.getExtras().getSerializable(MainActivity.SERVICE_LIST);

        //services = RoutexCommandsHandler.services;

        int len = services.size();
        for (int i = 0; i < len; i++) {
            Log.w("Service Name", services.get(i).getName());
        }

        /* Discovering */
        mba.startDiscovery();
        Log.w("Service", "Start Discovery");
        messageToActivity(MainActivity.STATUS_DISCOVERY);
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(ActionFoundReceiver, filter);

        return Service.START_NOT_STICKY;
    }


    @Override
    public void onDestroy() {
        //unregisterReceiver(ActionFoundReceiver);
        super.onDestroy();
        isActive = false;
        if (mba.isDiscovering()) mba.cancelDiscovery();
        messageToActivity(MainActivity.STATUS_STOPPED);
        Log.w("Service", "Stopped");
    }


    public boolean isActive() {
        return isActive;
    }

    public void messageToActivity(String status) {
        Intent intent = new Intent(MainActivity.STATUS_UPDATE_INTENT);
        intent.putExtra(MainActivity.STATUS_VALUE, status);
        Log.w("Sending Broadcast", status);
        sendBroadcast(intent);
    }

    public final BroadcastReceiver ActionFoundReceiver = new BroadcastReceiver(){

        @Override
        public void onReceive(final Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothDevice.ACTION_FOUND.equals(action)) {
                final BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                String info = new String(device.getName() + "\n" + device.getAddress());
                Log.e("EX", info);

                /* Get list of service uuids of device */
                //device.fetchUuidsWithSdp();
                ParcelUuid[] uuids = device.getUuids();

                if (uuids != null) {
                    for (int i = 0; i < uuids.length; i++) {

                        Log.e("UUID", uuids[i].toString());

                        /* If correct service UUID is found then start connection */
                        if (uuids[i].toString().toLowerCase().equals(MainActivity.SERVER_UUID.toString().toLowerCase())) {
                            Log.w("Service", "Service found!");
                            mba.cancelDiscovery();
                            Log.w("Service", "Stop Discovery");

                            routexManager.connectToRoutex(device);

                            return;
                        }
                    }
                }
                messageToActivity(MainActivity.STATUS_NOT_FOUND);
                Log.w("Service", "Device does not match service");
            }
        }
    };

    public static boolean askForCommands() {
        if (isActive) {
            routexManager.askForCommands();
            return true;
        }
        else return false;
    }
}
