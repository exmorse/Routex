package it.ex.bluetoothroutexclient;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by ex on 08/08/16.
 */
public class BluetoothRoutexManager {

    public static char NO_PARAM = 'B';
    public static char PARAM = 'I';

    public static char STATUS = 'S';
    public static char NUMBER = 'N';
    public static char TEXT = 'T';


    BluetoothServerSocket mmServerSocket;

    BluetoothAdapter mba;
    private BluetoothDevice routexDevice;
    private BluetoothSocket btSocket;
    boolean alwaysOn;
    String deviceName;
    BluetoothRoutexService bluetoothRoutexService;
    Context context;

    AcceptThread acceptThread;

    public BluetoothRoutexManager(Context context, BluetoothRoutexService bluetoothRoutexService, BluetoothAdapter ba, boolean alwaysOn) {
        mba = ba;
        this.bluetoothRoutexService = bluetoothRoutexService;
        this.context = context;
        this.alwaysOn = alwaysOn;
        acceptThread = new AcceptThread();
    }


    public boolean connect() {
        try {
            btSocket = routexDevice.createRfcommSocketToServiceRecord(MainActivity.SERVER_UUID);
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (!btSocket.isConnected()) {
            try {
                btSocket.connect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (btSocket.isConnected()) {
            Log.d("Bluetooth", "Connected");

            return true;
        }
        else return false;
    }

    public void connectToRoutex(BluetoothDevice routexDevice) {
        this.routexDevice = routexDevice;

        bluetoothRoutexService.messageToActivity(MainActivity.STATUS_JOINING);
        registerDevice("Tablet-1");

        for (DeviceService serv:BluetoothRoutexService.services) {
            registerService(serv.getName(), serv.getType());
            for (DeviceCommand com:serv.getCommands()) {
                addCommandToService(com.getName(), com.getType());
            }
            doneService();
        }


        bluetoothRoutexService.messageToActivity(MainActivity.STATUS_JOINED);

        if (alwaysOn) acceptThread.start();

    }

    void registerDevice(String devName) {

        deviceName = devName;

        if (connect()) {
            try {
                if (alwaysOn) btSocket.getOutputStream().write(("J!" + devName + "!A").getBytes("UTF-8"));
                else btSocket.getOutputStream().write(("J!" + devName + "!F").getBytes("UTF-8"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(btSocket.getInputStream()));
                String msg = in.readLine();

                if (msg.matches("J!Ok")) Log.w("Routex", "Device Registered");
                btSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    void registerService(String servName, char type) {
        if (connect()) {
            String data = "S!A!" + type + '!' + servName;
            try {
                Log.w("Register Service", data);
                btSocket.getOutputStream().write(data.getBytes("UTF-8"));
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(btSocket.getInputStream()));
                String msg = in.readLine();

                if (msg.matches("S!G!Ok")) Log.w("Routex", "Service Registered");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    void doneService() {
        String data = "S!DONE";
        try {
            btSocket.getOutputStream().write(data.getBytes("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(btSocket.getInputStream()));
            String msg = in.readLine();

            if (msg.matches("S!DONE!Ok")) Log.w("Routex", "Done Service");
            btSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void addCommandToService(String commandName, char type) {
        String data = "S!" + type + "!" + commandName;

        try {
            btSocket.getOutputStream().write(data.getBytes("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(btSocket.getInputStream()));
            String msg = in.readLine();

            if (msg.matches("C!Added")) Log.w("Routex", "Command added");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void serviceResponse(String response) {
        String data = "S!" + response;

        try {
            btSocket.getOutputStream().write(data.getBytes("UTF-8"));
            Log.w("Routex", "Response Sent");
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            btSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void askForCommands() {
        Log.w("Not Always On", "Ask for commands");
        acceptThread = new AcceptThread();
        acceptThread.start();

    }




    private class AcceptThread extends Thread {

        long alwaysOnTimeout;

        public AcceptThread() {
            /* Use a temporary object that is later assigned to mmServerSocket,
               because mmServerSocket is final */
            /*
            try {
                // "ExBluetoothService" is the Bluetooth Service name
                mmServerSocket = MainActivity.mba.listenUsingRfcommWithServiceRecord(mba.getAddress().toString(), MainActivity.UUID);
                Log.w("Service Name", mba.getAddress().toString());

            } catch (IOException e) {
                Log.d("THREAD SERVER", "Server Socket is null");
                Log.e("THREAD SERVER", e.getMessage());
            }*/
        }

        public void run() {
            /* Keep listening until exception occurs or a socket is returned */
            if (!alwaysOn) {
                if (connect()) {
                    try {
                        Log.w("Connected", "Sending AWAKE");
                        btSocket.getOutputStream().write(("W!AWAKE").getBytes("UTF-8"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            while (true) {
                alwaysOnTimeout = System.currentTimeMillis();
                try {
                    if (mmServerSocket != null) mmServerSocket.close();
                    mmServerSocket = MainActivity.mba.listenUsingRfcommWithServiceRecord(mba.getAddress().toString(), MainActivity.CLIENT_UUID);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                try {
                    //mmServerSocket = MainActivity.mba.listenUsingRfcommWithServiceRecord(mba.getAddress().toString(), MainActivity.CLIENT_UUID);
                    Log.w("Service Name", mba.getAddress().toString());
                    Log.d("THREAD SERVER", "Accepting...");
                    bluetoothRoutexService.messageToActivity(MainActivity.STATUS_ACCEPTING);
                    if (alwaysOn) btSocket = mmServerSocket.accept();
                    else {
                        try {
                            btSocket = mmServerSocket.accept(8000);
                        }
                        catch (IOException e) {
                            mmServerSocket.close();
                            btSocket.close();
                            Log.w("Accept", "Timeout Expired");
                            return;
                        }
                    }
                    Log.d("THREAD SERVER", "Accepted");
                } catch (IOException e) {
                }
            /* If a connection was accepted */
                if (btSocket != null) {
                    Log.d("THREAD SERVER", "Client non Null");

                    String msg = "";

                    try {

                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(btSocket.getInputStream()));
                        Log.w("Service", "Reading");

                        msg = in.readLine();

                        Log.w("Received", msg);

                        if (msg.matches("W!FINISHED") || msg.matches("W!FINISHED\n")) {
                            Log.w("Accept Thread", "Should finish");
                            btSocket.close();
                            mmServerSocket.close();
                            Log.w("Closing", "SDP Service should stop");
                            return;
                        }

                        /* Need to interpret message (service + command) */
                        String result = interpretCommandMessage(msg);

                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        serviceResponse(result);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    /*try {
                        mmServerSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }*/
                }
            }
        }

        String interpretCommandMessage(String string) {
            String serviceName;
            String commandName;
            String argument = null;
            boolean hasArg = false;
            int separatorIndex = string.indexOf('!');
            int len = string.length();

            if (string.charAt(len-1) == '*') {
                hasArg = true;
            }

            serviceName = string.substring(0, separatorIndex);
            if (hasArg) {
                commandName = string.substring(separatorIndex+1, len-1);
            }
            else {
                commandName = string.substring(separatorIndex+1);
            }

            Log.w("Service Name", serviceName);
            Log.w("Command Name", commandName);

            if (hasArg) {
                BufferedReader in = null;
                try {
                    in = new BufferedReader(
                            new InputStreamReader(btSocket.getInputStream()));
                            String msg = in.readLine();

                            if (msg.substring(0, 2).matches("\\*!")) {
                                argument = msg.substring(2);
                            }
                } catch (IOException e) {
                    e.printStackTrace();
                };
            }

            if (argument != null) Log.w("Command Argument", argument);

            return BluetoothRoutexService.execute(context, serviceName, commandName, argument);
        }

        /* Will cancel the listening socket, and cause the thread to finish */
        public void cancel() {
            try {
                Log.d("THREAD SERVER", "Cancelling");
                mmServerSocket.close();
                if (mba.isDiscovering()) mba.cancelDiscovery();
            } catch (IOException e) { }
        }
    }
}
