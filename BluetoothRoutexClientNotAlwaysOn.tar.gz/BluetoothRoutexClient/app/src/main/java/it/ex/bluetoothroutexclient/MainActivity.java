package it.ex.bluetoothroutexclient;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static String SERVICE_LIST = "service_list";
    public static String STATUS_UPDATE_INTENT = "status_update";
    public static String STATUS_VALUE = "status_value";

    public static String STATUS_DISCOVERY = "Discovery";
    public static String STATUS_NOT_FOUND = "Routex not found";
    public static String STATUS_JOINING = "Joining";
    public static String STATUS_JOINED = "Joined";
    public static String STATUS_ACCEPTING = "Accepting command";
    public static String STATUS_REPLYING = "Replying";
    public static String STATUS_STOPPED = "Stopped";
    public static String STATUS_RUNNING = "Running";



    RecyclerView serviceRecView;
    ServiceRecViewAdapter adapter;
    private RecyclerView.LayoutManager recyclerLayoutManager;

    public static ArrayList<DeviceService> allServices;
    public static ArrayList<DeviceService> activeServices;

    Button connectButton;
    Button disconnectButton;
    Button askForCommandButton;

    TextView statusTextView;

    Switch alwaysOnSwitch;

    Context context;

    private StatusUpdateReceiver statusUpdateReceiver;

    /* Bluetooth Service UUID */
    protected static java.util.UUID SERVER_UUID = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    protected static java.util.UUID CLIENT_UUID = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FC");

    /* StartActivityForResult Code */
    private int REQUEST_ENABLE_BT = 1;

    public static BluetoothAdapter mba;

    Camera cam;


    /* Service */
    BluetoothRoutexService btService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        context = this;

        /* Broadcast receiver for status update */
        if (statusUpdateReceiver == null) {
            statusUpdateReceiver = new StatusUpdateReceiver();
            IntentFilter intentFilter = new IntentFilter(STATUS_UPDATE_INTENT);
            registerReceiver(statusUpdateReceiver, intentFilter);
        }


        /* Status Text View */
        statusTextView = (TextView) findViewById(R.id.status_text);
        if (BluetoothRoutexService.isActive)
            statusTextView.setText(STATUS_RUNNING);
        else
            statusTextView.setText(STATUS_STOPPED);


        /* Always On Switch */
        alwaysOnSwitch = (Switch) findViewById(R.id.always_on_switch);


        /* Bluetooth Service */
        btService = new BluetoothRoutexService();


        /* Service List */
        serviceRecView = (RecyclerView) findViewById(R.id.services_rec_view);

        allServices = new ArrayList<DeviceService>();

        DeviceService batteryService = new DeviceService("Battery", BluetoothRoutexManager.NUMBER);
        batteryService.addCommand(new DeviceCommand("Get", BluetoothRoutexManager.NO_PARAM, new CommandBehaviour() {
            @Override
            public String execute(Context c, String argument) {
                //return "25";
                BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
                int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                return batLevel + "";
            }
        }));

        DeviceService torchService = new DeviceService("Torch", BluetoothRoutexManager.STATUS);
        torchService.addCommand(new DeviceCommand("Turn On", BluetoothRoutexManager.NO_PARAM, new CommandBehaviour() {
            @Override
            public String execute(Context c, String argument) {
                try {
                    cam = null;
                    if (getPackageManager().hasSystemFeature(
                            PackageManager.FEATURE_CAMERA_FLASH)) {
                        cam = Camera.open();
                        Camera.Parameters p = cam.getParameters();
                        p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                        cam.setParameters(p);
                        cam.startPreview();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    //Toast.makeText(getBaseContext(), "Exception flashLightOn()",
                            //Toast.LENGTH_SHORT).show();
                }
                return "On";
            }
        }));
        torchService.addCommand(new DeviceCommand("Turn Off", BluetoothRoutexManager.NO_PARAM, new CommandBehaviour() {
            @Override
            public String execute(Context c, String argument) {
                try {
                    if (getPackageManager().hasSystemFeature(
                            PackageManager.FEATURE_CAMERA_FLASH)) {
                        cam.stopPreview();
                        cam.release();
                        cam = null;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    //Toast.makeText(getBaseContext(), "Exception flashLightOff",
                      //      Toast.LENGTH_SHORT).show();
                }
                return "Off";
            }
        }));

        allServices.add(batteryService);
        allServices.add(torchService);

        activeServices = (ArrayList<DeviceService>) allServices.clone();

        //RoutexCommandsHandler.setServices(services);

        recyclerLayoutManager = new LinearLayoutManager(this);
        serviceRecView.setLayoutManager(recyclerLayoutManager);
        adapter = new ServiceRecViewAdapter(allServices);
        serviceRecView.setAdapter(adapter);


        /* Connect Buttons */
        connectButton = (Button) findViewById(R.id.connect_button);
        disconnectButton = (Button) findViewById(R.id.disconnect_button);
        askForCommandButton = (Button) findViewById(R.id.ask_for_commands_button);

        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BluetoothRoutexService.setServices(activeServices);
                BluetoothRoutexService.alwaysOn = alwaysOnSwitch.isChecked();
                Intent intent = new Intent(context, BluetoothRoutexService.class);
                startService(intent);
            }
        });

        disconnectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //stopService()
                stopService(new Intent(context, BluetoothRoutexService.class));
            }
        });

        askForCommandButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BluetoothRoutexService.askForCommands();
            }
        });


        /* Bluetooth Manager */
        mba = BluetoothAdapter.getDefaultAdapter();
        if (mba == null) {
            Toast.makeText(this, "Bluetooth Not Available", Toast.LENGTH_SHORT).show();
            connectButton.setEnabled(false);
            disconnectButton.setEnabled(false);
        }
        else {
            /* If Bluetooth is not enabled launch an intent to request the activation */
            if (!mba.isEnabled()) {
                Intent enableBT = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBT, REQUEST_ENABLE_BT);
            }
        }
    }


    private class StatusUpdateReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(STATUS_UPDATE_INTENT)) {

                Log.w("BroadcastMessage", "Received");
                //statusTextView.setText(intent.getStringExtra(STATUS_VALUE));
                statusTextView.setText(intent.getExtras().getString(STATUS_VALUE));
            }
        }
    }

    public static void addToActiveServices(int index) {
        activeServices.add(allServices.get(index));
    }

    public static void removeFromActiveServices(int index) {
        int z;
        for (z = 0; z < activeServices.size(); z++) {
            if (activeServices.get(z).getName().matches(allServices.get(index).getName())) {
                activeServices.remove(z);
            }
        }
    }

    @Override
    public void onPause() {
        //if (statusUpdateReceiver != null) unregisterReceiver(statusUpdateReceiver);
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
