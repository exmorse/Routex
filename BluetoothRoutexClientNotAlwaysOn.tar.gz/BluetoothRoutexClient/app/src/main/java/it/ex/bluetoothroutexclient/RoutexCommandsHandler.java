package it.ex.bluetoothroutexclient;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by ex on 09/08/16.
 */
public class RoutexCommandsHandler {

    public static ArrayList<DeviceService> services;

    public static void setServices(ArrayList<DeviceService> serviceArrayList) {
        services = (ArrayList<DeviceService>) serviceArrayList.clone();
    }

    public static String execute(Context context, String serviceName, String commandName, String argument) {

        /*Log.w("Execute", serviceName + " " + commandName);
        if (serviceName.matches("Battery")) {
            if (commandName.matches("Get")) {
                return "50";
            }
        }*/
        int i;
        for (i = 0; i < services.size(); i++) {
            DeviceService serv = services.get(i);
            if (serv.getName().matches(serviceName)) {
                int j;
                for (j = 0; j < serv.getCommands().size(); j++) {
                    DeviceCommand com = serv.getCommands().get(j);
                    if (com.getName().matches(commandName)) {
                        return com.run(context, argument);
                    }
                }
            }
        }

        return "Not Found";
    }
}
