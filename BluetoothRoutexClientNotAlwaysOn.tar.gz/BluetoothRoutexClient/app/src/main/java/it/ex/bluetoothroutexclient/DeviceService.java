package it.ex.bluetoothroutexclient;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by ex on 08/08/16.
 */
public class DeviceService {

    protected String name;
    protected char type;
    protected ArrayList<DeviceCommand> commands;

    public DeviceService(String name, char type) {
        this.name = name;
        this.type = type;
        commands = new ArrayList<DeviceCommand>();
    }

    public String getName() {
        return name;
    }

    public char getType() {
        return type;
    }

    public void addCommand(DeviceCommand com) {
        commands.add(com);
    }

    public ArrayList<DeviceCommand> getCommands() {
        return commands;
    }

}
