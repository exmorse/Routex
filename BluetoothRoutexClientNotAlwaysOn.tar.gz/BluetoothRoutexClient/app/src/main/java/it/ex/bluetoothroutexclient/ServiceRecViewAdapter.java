package it.ex.bluetoothroutexclient;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;

/**
 * Created by ex on 08/08/16.
 */
public class ServiceRecViewAdapter extends RecyclerView.Adapter {

    ArrayList<DeviceService> services;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        CheckBox serviceCheckBox;

        public MyViewHolder(View itemView) {
            super(itemView);
            serviceCheckBox = (CheckBox) itemView.findViewById(R.id.service_element_checkbox);
            serviceCheckBox.setChecked(true);

            serviceCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        MainActivity.addToActiveServices(getPosition());
                    }
                    if (!isChecked) {
                        MainActivity.removeFromActiveServices(getPosition());
                    }
                }
            });

            /*deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("Delete", getPosition()+"");
                    MainActivity.deleteLocationAtPosition(getPosition());
                }
            });
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("ClickedElement", getPosition()+"");
                    MainActivity.showInMapLocationAtPosition(getPosition());
                }
            });*/
        }

    }

    public ServiceRecViewAdapter(ArrayList<DeviceService> s) {
        services = s;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.service_list_element, parent, false);

        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((MyViewHolder)holder).serviceCheckBox.setText(services.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return services.size();
    }
}
