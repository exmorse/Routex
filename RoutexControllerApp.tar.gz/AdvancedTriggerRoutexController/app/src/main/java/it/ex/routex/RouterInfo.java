package it.ex.routex;

/**
 * Created by ex on 21/06/16.
 */
public class RouterInfo {

    String statusMessage;

    public RouterInfo(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }
}
